<?php

/**
 * Plugin Name: Hexella Custom Title Woocommerce
 * Description: Adds custom Title boxes to product categories in WooCommerce.
 * Version: 1.0
 * Author: Mohsen Hooshmand
 * Author URL: https://hexella.com/
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

require_once plugin_dir_path(__FILE__) . 'includes/hexella-custom-meta-title-woocommerce.php';
